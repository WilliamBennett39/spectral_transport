import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import h5py
import sys

if len(sys.argv) != 2:
    print("Usage: python mcdc_array.py <mcdc_file.h5>")
    sys.exit(1)

output_mcdc = sys.argv[1]

L = 9.1

# Get MCDC results
with h5py.File(output_mcdc, "r") as f:
    x = f["tallies/mesh_tally_0/grid/x"][:]
    dx = x[1:] - x[:-1]
    x_mc = 0.5 * (x[1:] + x[:-1])

    t = f["tallies"]["mesh_tally_0"]["grid"]["t"][:]
    dt     = t[1:] - t[:-1]

    I = len(x) -1
    T = len(t) -1

    psi = f["tallies/mesh_tally_0/flux/mean"][:]
    psi_sd = f["tallies/mesh_tally_0/flux/sdev"][:]

    psi = np.transpose(psi)
    psi_sd = np.transpose(psi_sd)

# Scalar flux
phi = np.zeros((I, T))
phi = psi.sum(axis=2)

# Normalization
phi = phi / (dx[:, np.newaxis] * dt[np.newaxis, :]) * L

# Print results

print(f'psi shape: {psi.shape}')
print(f'phi shape: {phi.shape}')
