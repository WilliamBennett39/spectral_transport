import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import h5py
import sys

if len(sys.argv) != 3:
    print("Usage: python process.py <sn_file.npz> <mcdc_file.h5>")
    sys.exit(1)

output_sn = sys.argv[1]
output_mcdc = sys.argv[2]

# Error functions
def error(val, ref):
    return np.sqrt(np.average((val - ref) ** 2) / np.sum(ref**2))

def error_max(val, ref):
    return np.max(val - ref) / np.max(ref)

# Get referance solution
L = 9.1
cells = 20
I = int(np.round(cells*L))
hx = L/I
x_sn= np.linspace(hx/2,L-hx/2,I)

data_sn = np.load(output_sn)
phi_data = data_sn['arr_0']
phi_sn_last = (phi_data[:,-1,-1])

# Get MCDC results
with h5py.File(output_mcdc, "r") as f:
    x = f["tallies/mesh_tally_0/grid/x"][:]
    dx = x[1:] - x[:-1]
    x_mc = 0.5 * (x[1:] + x[:-1])

    t = f["tallies"]["mesh_tally_0"]["grid"]["t"][:]
    dt     = t[1:] - t[:-1]

    I = len(x) -1
    T = len(t) -1

    psi = f["tallies/mesh_tally_0/flux/mean"][:]
    psi_sd = f["tallies/mesh_tally_0/flux/sdev"][:]

    psi = np.transpose(psi)
    psi_sd = np.transpose(psi_sd)

# Scalar flux
phi = np.zeros((I, T))
phi = psi.sum(axis=2)

# Normalization
phi = phi / (dx[:, np.newaxis] * dt[np.newaxis, :]) * L

phi_mc_last = phi[:, -1]

# Print error results
print(f'L-2 Norm = {error(phi_mc_last, phi_sn_last)}')
print(f'Max Norm = {error_max(phi_mc_last, phi_sn_last)}')

# Plot results
plt.plot(x_sn, phi_sn_last, label='SN')
plt.plot(x_mc, phi_mc_last, label='MC')
# plt.yscale('log')
plt.xlabel('x [cm]')
plt.ylabel(r'$\phi$ [n/cm$^2$-s]')
plt.title('Asymmetric SuperCritical - 20 Cells')
plt.legend()
plt.grid()
plt.show()
