import numpy as np
import mcdc
import math
import time


# =============================================================================
# Set model
# =============================================================================

# Set materials

# Fissile material (regions [0–1), [8–9.1)):
mat_fissile = mcdc.material(
    capture = np.array([0.0]),
    scatter = np.array([[0.8]]),
    fission = np.array([0.2]),
    nu_p    = np.array([3.5]),
    chi_p   = np.array([[1.0]]),
    speed   = np.array([1.0])
)

# Scattering‐only material (regions [1–2), [7–8)):
mat_scatter = mcdc.material(
    capture = np.array([0.2]),
    scatter = np.array([[0.8]]),
    speed   = np.array([1.0])
)

# Low‐scatter material (region [2–7)):
mat_lowscatter = mcdc.material(
    capture = np.array([0.9]),
    scatter = np.array([[0.1]]),
    speed   = np.array([1.0])
)

# Set surfaces
s0  = mcdc.surface(type_='plane-x', x=0.0, bc='vacuum') #left
s5 = mcdc.surface(type_='plane-x', x=9.1, bc='vacuum')  #right

s1 = mcdc.surface(type_='plane-x', x=1.0)
s2 = mcdc.surface(type_='plane-x', x=2.0)
s3 = mcdc.surface(type_='plane-x', x=7.0)
s4 = mcdc.surface(type_='plane-x', x=8.0)

# Set cells
cell1 = mcdc.cell(+s0&-s1, mat_fissile)
cell2 = mcdc.cell(+s1&-s2, mat_scatter)
cell3 = mcdc.cell(+s2&-s3, mat_lowscatter)
cell4 = mcdc.cell(+s3&-s4, mat_scatter)
cell5 = mcdc.cell(+s4&-s5, mat_fissile)

# =============================================================================
# Set source
# =============================================================================

# at t=0, isotropic dist source
G = 1
energy = np.zeros(G)
energy[-1] = 1.0
mcdc.source(
    x         = [0.0, 9.1],   # uniform over whole slab
    isotropic = True,
    energy    = energy,        # group 1 only
    time      = [0.0, 0.0]    # emit only at t=0
)

# =============================================================================
# Set tally, setting, and run mcdc
# =============================================================================

N = 196
numsteps = 20
L = 9.1
n_cells = 20
I = int(np.round(n_cells * L))
MU, W = np.polynomial.legendre.leggauss(N)
mu_edges = np.empty(N+1)
mu_edges[0]      = -1.0
mu_edges[-1]     = +1.0
mu_edges[1:-1]   = 0.5 * (MU[:-1] + MU[1:])
x_edges = np.linspace(0.0, 9.1, I+1)
ts = np.logspace(-1, math.log10(10), numsteps + 1)

#Tally
mcdc.tally.mesh_tally(
    scores=["flux"],
    x  = x_edges,
    mu = mu_edges,
    t = ts,
)

mcdc.setting(
    N_particle    = 100_000,
    time_boundary = float(ts[-1]),
    output_name   = "mg_td_88",
    census_bank_buff = 2.0,
    active_bank_buff = 1_000_000
)

mcdc.time_census(ts)
mcdc.population_control()
mcdc.implicit_capture()

mcdc.run()