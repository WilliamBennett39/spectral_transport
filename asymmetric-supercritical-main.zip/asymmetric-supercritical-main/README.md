# Usage

```bash
python process.py <sn_file.npz> <mcdc_file.h5>
```

# Input File Descriptions:

## MCDC input file

`asymmetric-supercritical_mcdc.py`

## SN files from Dr. Ryan McClarren's [VDMD repository](https://github.com/DrRyanMc/VDMD/tree/main/SN)

`asymmetric-supercritical_sn.py`

`multigroup_sn.py`

## Process & Run file 

`process.py`

# Output files

`sn_asymmetric-super_phi_20_196.npz`: 20 cells, 196 Gauss–Legendre quadrature points

`mcdc_asymmetric-super_1e5_196.h5`: 10e5 particles, 196 angular bins